fail2ban.version module
=======================

.. automodule:: fail2ban.version
    :members:
    :undoc-members:
    :show-inheritance:
