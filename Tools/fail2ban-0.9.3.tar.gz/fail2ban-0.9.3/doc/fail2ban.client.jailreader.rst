fail2ban.client.jailreader module
=================================

.. automodule:: fail2ban.client.jailreader
    :members:
    :undoc-members:
    :show-inheritance:
