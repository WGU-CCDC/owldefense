fail2ban.server.filterpyinotify module
======================================

.. automodule:: fail2ban.server.filterpyinotify
    :members:
    :undoc-members:
    :show-inheritance:
