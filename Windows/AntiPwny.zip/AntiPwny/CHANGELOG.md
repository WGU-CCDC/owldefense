November 15, 2013
--------
* Fixed Self-Detection of AntiPwny. Migrated Processes will not be correctly detected.
* Added version numbers to executable
