Run this script from an elevated prompt(either right click and Run As or run from an elevated command prompt)!!!

Once done installing, don't forget to reboot.